#!/bin/bash
apt install apache2 -y

